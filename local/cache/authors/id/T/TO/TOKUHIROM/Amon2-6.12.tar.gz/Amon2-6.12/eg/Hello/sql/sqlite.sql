drop table if exists entry;
CREATE TABLE `entry` (
    `entry_id` integer NOT NULL primary key,
    `body`     text
);
