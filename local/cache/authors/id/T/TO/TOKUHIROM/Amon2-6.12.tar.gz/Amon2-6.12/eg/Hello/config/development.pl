+{

    'DBIx::Skinny' => {
        dsn => 'dbi:SQLite:dbname=test.db',
        username => '',
        password => '',
    },

    'Text::Xslate' => {
        path => ['tmpl/'],
    },
};
