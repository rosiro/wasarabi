package Hello::Web::Response;
use strict;
use parent qw/Amon2::Web::Response/;
1;
