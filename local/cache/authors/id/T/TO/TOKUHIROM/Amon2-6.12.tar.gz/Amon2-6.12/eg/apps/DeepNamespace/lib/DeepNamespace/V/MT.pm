package DeepNamespace::V::MT;
use Amon2::V::MT -base;
1;
